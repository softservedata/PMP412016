﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UserExamle.Data;

namespace UserExamle
{
    class Program
    {
        static void Main(string[] args)
        {
            //User user = new User("11", "22", "33", "44", "55");
            User user = new User();
            user.setLogin("11");
            user.setFirsname("22");
            user.setLastname("33");
            user.setPassword("44");
            user.setEmail("55");
            //Console.WriteLine("login=" + user.login);
            Console.WriteLine("login=" + user.getLogin());
            Console.WriteLine("End");
        }
    }
}
