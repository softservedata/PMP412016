﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserExamle.Data
{
    class User
    {
        public string login { get; private set; }
        public string firsname { get; private set; }
        public string lastname { get; private set; }
        public string password { get; private set; }
        public string email { get; private set; }

        public User(string login, string firsname, string lastname, string password, string email)
        {
            this.login = login;
            this.firsname = firsname;
            this.lastname = lastname;
            this.password = password;
            this.email = email;
        }
    }
}
