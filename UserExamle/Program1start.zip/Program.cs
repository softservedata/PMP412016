﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UserExamle.Data;

namespace UserExamle
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User("11", "22", "33", "44", "55");
            Console.WriteLine("login=" + user.login);
            Console.WriteLine("End");
        }
    }
}
